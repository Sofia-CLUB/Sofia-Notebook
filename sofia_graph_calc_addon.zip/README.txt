SOFIA NOTEBOOK — GRAPH + CALCULATOR ADDON

1. Завантажте у корінь репозиторію два файли:
   graph-calculator-addon.js
   graph-calculator-addon.css

2. У index.html всередині <head> додайте:
   <link rel="stylesheet" href="graph-calculator-addon.css">

3. Перед </body> додайте:
   <script src="graph-calculator-addon.js"></script>

4. Збережіть зміни, зачекайте GitHub Pages 1–2 хв і натисніть Ctrl+F5.

Аддон автоматично додасть у верхню панель:
📈 Графіки
🧮 Калькулятор
