
(function(){
  function ready(fn){
    if(document.readyState==="loading") document.addEventListener("DOMContentLoaded",fn);
    else fn();
  }

  ready(function(){
    const topActions=document.querySelector(".top-actions") || document.body;

    // ---------- Buttons ----------
    const graphBtn=document.createElement("button");
    graphBtn.id="graphBtn";
    graphBtn.className="top-btn";
    graphBtn.textContent="📈 Графіки";

    const calcBtn=document.createElement("button");
    calcBtn.id="calculatorBtn";
    calcBtn.className="top-btn";
    calcBtn.textContent="🧮 Калькулятор";

    topActions.appendChild(graphBtn);
    topActions.appendChild(calcBtn);

    // ---------- Graph panel ----------
    const graphPanel=document.createElement("div");
    graphPanel.id="graphPanel";
    graphPanel.className="sg-addon-panel hidden";
    graphPanel.innerHTML=`
      <div class="sg-addon-head">
        <div><b>📈 Декартова система та графіки</b><span>функції, точки, координатна площина</span></div>
        <button id="graphCloseBtn">×</button>
      </div>

      <div class="sg-tabs">
        <button class="sg-tab active" data-tab="function">Функція</button>
        <button class="sg-tab" data-tab="point">Точка</button>
        <button class="sg-tab" data-tab="plane">Площина</button>
      </div>

      <div class="sg-section" data-section="function">
        <label>Функція y =
          <input id="graphExpression" value="x" placeholder="Напр.: x^2 - 4">
        </label>
        <div class="sg-presets">
          <button data-expr="x">y=x</button>
          <button data-expr="2*x+1">y=2x+1</button>
          <button data-expr="x^2">y=x²</button>
          <button data-expr="abs(x)">y=|x|</button>
          <button data-expr="1/x">y=1/x</button>
          <button data-expr="sqrt(x)">y=√x</button>
          <button data-expr="sin(x)">sin x</button>
          <button data-expr="cos(x)">cos x</button>
        </div>

        <div class="sg-range">
          <label>x min<input id="graphXMin" type="number" value="-10"></label>
          <label>x max<input id="graphXMax" type="number" value="10"></label>
          <label>y min<input id="graphYMin" type="number" value="-10"></label>
          <label>y max<input id="graphYMax" type="number" value="10"></label>
        </div>

        <label>Колір графіка <input id="graphColor" type="color" value="#e53935"></label>
        <button id="insertGraphBtn" class="sg-primary">Вставити графік</button>
      </div>

      <div class="sg-section hidden" data-section="point">
        <div class="sg-range">
          <label>x<input id="pointX" type="number" step="0.1" value="2"></label>
          <label>y<input id="pointY" type="number" step="0.1" value="3"></label>
          <label>Назва<input id="pointLabel" value="A" maxlength="4"></label>
        </div>
        <button id="insertPointBtn" class="sg-primary">• Вставити точку</button>
      </div>

      <div class="sg-section hidden" data-section="plane">
        <p>Вставте чисту декартову систему й далі працюйте на ній ручкою, лініями або точками.</p>
        <button id="insertPlaneBtn" class="sg-primary">＋ Вставити координатну площину</button>
      </div>
    `;
    document.body.appendChild(graphPanel);

    // ---------- Calculator panel ----------
    const calcPanel=document.createElement("div");
    calcPanel.id="calculatorPanel";
    calcPanel.className="sg-addon-panel sg-calc-panel hidden";
    calcPanel.innerHTML=`
      <div class="sg-addon-head">
        <div><b>🧮 Калькулятор</b><span>для інтерактивної дошки</span></div>
        <button id="calculatorCloseBtn">×</button>
      </div>
      <input id="calcDisplay" class="sg-calc-display" placeholder="0">
      <div class="sg-calc-grid">
        <button data-calc="clear">C</button><button data-calc="back">⌫</button><button data-calc="(">(</button><button data-calc=")">)</button>
        <button data-calc="7">7</button><button data-calc="8">8</button><button data-calc="9">9</button><button data-calc="/">÷</button>
        <button data-calc="4">4</button><button data-calc="5">5</button><button data-calc="6">6</button><button data-calc="*">×</button>
        <button data-calc="1">1</button><button data-calc="2">2</button><button data-calc="3">3</button><button data-calc="-">−</button>
        <button data-calc="0">0</button><button data-calc=".">,</button><button data-calc="^">xʸ</button><button data-calc="+">＋</button>
        <button data-calc="sqrt(">√</button><button data-calc="sin(">sin</button><button data-calc="cos(">cos</button><button data-calc="tan(">tan</button>
        <button data-calc="pi">π</button><button data-calc="percent">%</button><button id="calcEquals" class="sg-primary">=</button><button id="calcInsert">Вставити</button>
      </div>
      <div id="calcResult" class="sg-calc-result"></div>
    `;
    document.body.appendChild(calcPanel);

    graphBtn.onclick=()=>{graphPanel.classList.toggle("hidden");calcPanel.classList.add("hidden")};
    calcBtn.onclick=()=>{calcPanel.classList.toggle("hidden");graphPanel.classList.add("hidden")};
    graphPanel.querySelector("#graphCloseBtn").onclick=()=>graphPanel.classList.add("hidden");
    calcPanel.querySelector("#calculatorCloseBtn").onclick=()=>calcPanel.classList.add("hidden");

    // ---------- Tabs ----------
    graphPanel.querySelectorAll(".sg-tab").forEach(btn=>{
      btn.onclick=()=>{
        graphPanel.querySelectorAll(".sg-tab").forEach(b=>b.classList.remove("active"));
        btn.classList.add("active");
        graphPanel.querySelectorAll("[data-section]").forEach(s=>s.classList.toggle("hidden",s.dataset.section!==btn.dataset.tab));
      };
    });

    graphPanel.querySelectorAll("[data-expr]").forEach(btn=>{
      btn.onclick=()=>graphPanel.querySelector("#graphExpression").value=btn.dataset.expr;
    });

    function getCanvas(){
      if(window.fcanvas) return window.fcanvas;
      try{ if(typeof fcanvas!=="undefined") return fcanvas; }catch(e){}
      alert("Не знайдено робоче полотно Sofia Notebook.");
      return null;
    }

    function saveCanvas(){
      try{ if(typeof pushHistory==="function")pushHistory(); }catch(e){}
      try{ if(typeof autoSave==="function")autoSave(); }catch(e){}
      try{ if(typeof setTool==="function")setTool("select"); }catch(e){}
    }

    // ---------- Coordinate plane ----------
    function createPlane(canvas,opts={}){
      const width=opts.width||560, height=opts.height||440;
      const xmin=Number(opts.xmin??-10), xmax=Number(opts.xmax??10);
      const ymin=Number(opts.ymin??-10), ymax=Number(opts.ymax??10);
      const left=opts.left??260, top=opts.top??180;
      const sx=width/(xmax-xmin), sy=height/(ymax-ymin);
      const xpx=x=>(x-xmin)*sx;
      const ypx=y=>height-(y-ymin)*sy;
      const zx=xpx(0), zy=ypx(0);
      const c="#17315f", grid="#d8e2ef";
      const objs=[
        new fabric.Rect({left:0,top:0,width,height,fill:"rgba(255,255,255,.94)",stroke:"#8fa1b9",strokeWidth:1,selectable:false,evented:false})
      ];

      for(let x=Math.ceil(xmin);x<=Math.floor(xmax);x++){
        const px=xpx(x);
        objs.push(new fabric.Line([px,0,px,height],{stroke:x===0?c:grid,strokeWidth:x===0?2:1,selectable:false,evented:false}));
        if(x!==0 && xmax-xmin<=30) objs.push(new fabric.Text(String(x),{left:px-5,top:Math.max(3,Math.min(height-17,zy+4)),fontSize:9,fill:c,selectable:false,evented:false}));
      }
      for(let y=Math.ceil(ymin);y<=Math.floor(ymax);y++){
        const py=ypx(y);
        objs.push(new fabric.Line([0,py,width,py],{stroke:y===0?c:grid,strokeWidth:y===0?2:1,selectable:false,evented:false}));
        if(y!==0 && ymax-ymin<=30) objs.push(new fabric.Text(String(y),{left:Math.max(4,Math.min(width-20,zx+5)),top:py-7,fontSize:9,fill:c,selectable:false,evented:false}));
      }

      if(zy>=0&&zy<=height){
        objs.push(new fabric.Triangle({left:width-5,top:zy,width:11,height:13,fill:c,angle:90,originX:"center",originY:"center",selectable:false,evented:false}));
        objs.push(new fabric.Text("x",{left:width-20,top:zy-24,fontSize:15,fill:c,fontWeight:"bold",selectable:false,evented:false}));
      }
      if(zx>=0&&zx<=width){
        objs.push(new fabric.Triangle({left:zx,top:5,width:11,height:13,fill:c,originX:"center",originY:"center",selectable:false,evented:false}));
        objs.push(new fabric.Text("y",{left:zx+9,top:5,fontSize:15,fill:c,fontWeight:"bold",selectable:false,evented:false}));
      }

      const group=new fabric.Group(objs,{left,top,selectable:true,evented:true});
      canvas.add(group);
      return {group,objs,xpx,ypx,width,height};
    }

    function compile(expr){
      let s=String(expr||"").trim().toLowerCase()
        .replace(/,/g,".")
        .replace(/\^/g,"**")
        .replace(/π|\bpi\b/g,"Math.PI")
        .replace(/\bsqrt\(/g,"Math.sqrt(")
        .replace(/\babs\(/g,"Math.abs(")
        .replace(/\bsin\(/g,"Math.sin(")
        .replace(/\bcos\(/g,"Math.cos(")
        .replace(/\btan\(/g,"Math.tan(")
        .replace(/\bln\(/g,"Math.log(")
        .replace(/\blog\(/g,"Math.log10(");
      return new Function("x",`"use strict";return (${s});`);
    }

    graphPanel.querySelector("#insertPlaneBtn").onclick=()=>{
      const canvas=getCanvas(); if(!canvas)return;
      const p=createPlane(canvas,{width:650,height:500,left:220,top:150});
      canvas.setActiveObject(p.group); saveCanvas(); graphPanel.classList.add("hidden");
    };

    graphPanel.querySelector("#insertPointBtn").onclick=()=>{
      const canvas=getCanvas(); if(!canvas)return;
      const x=Number(graphPanel.querySelector("#pointX").value||0);
      const y=Number(graphPanel.querySelector("#pointY").value||0);
      const label=(graphPanel.querySelector("#pointLabel").value||"A").trim();
      const p=createPlane(canvas,{left:260,top:170});
      const all=p.group._objects.slice(); canvas.remove(p.group);
      const px=p.xpx(x), py=p.ypx(y);
      all.push(new fabric.Circle({left:px-5,top:py-5,radius:5,fill:"#e53935",selectable:false,evented:false}));
      all.push(new fabric.Text(`${label}(${x}; ${y})`,{left:px+8,top:py-20,fontSize:14,fill:"#e53935",fontWeight:"bold",selectable:false,evented:false}));
      const g=new fabric.Group(all,{left:260,top:170}); canvas.add(g); canvas.setActiveObject(g); saveCanvas();
    };

    graphPanel.querySelector("#insertGraphBtn").onclick=()=>{
      const canvas=getCanvas(); if(!canvas)return;
      const xmin=Number(graphPanel.querySelector("#graphXMin").value||-10);
      const xmax=Number(graphPanel.querySelector("#graphXMax").value||10);
      const ymin=Number(graphPanel.querySelector("#graphYMin").value||-10);
      const ymax=Number(graphPanel.querySelector("#graphYMax").value||10);
      if(!(xmax>xmin&&ymax>ymin)){alert("Перевірте межі осей.");return}
      let fn;
      try{fn=compile(graphPanel.querySelector("#graphExpression").value||"x")}
      catch(e){alert("Не вдалося прочитати функцію.");return}

      const p=createPlane(canvas,{xmin,xmax,ymin,ymax,left:260,top:170});
      const all=p.group._objects.slice(); canvas.remove(p.group);
      const color=graphPanel.querySelector("#graphColor").value||"#e53935";
      const segments=[]; let cur=[];
      for(let i=0;i<=800;i++){
        const x=xmin+(xmax-xmin)*i/800;
        let y; try{y=fn(x)}catch(e){y=NaN}
        const valid=Number.isFinite(y)&&y>=ymin-(ymax-ymin)*.08&&y<=ymax+(ymax-ymin)*.08;
        if(valid){
          const px=p.xpx(x),py=p.ypx(y);
          if(cur.length&&Math.abs(py-cur[cur.length-1][1])>p.height*.45){if(cur.length>1)segments.push(cur);cur=[]}
          cur.push([px,py]);
        }else{if(cur.length>1)segments.push(cur);cur=[]}
      }
      if(cur.length>1)segments.push(cur);

      segments.forEach(arr=>{
        let d=`M ${arr[0][0]} ${arr[0][1]}`;
        for(let i=1;i<arr.length;i++)d+=` L ${arr[i][0]} ${arr[i][1]}`;
        all.push(new fabric.Path(d,{stroke:color,strokeWidth:3,fill:"transparent",selectable:false,evented:false}));
      });
      all.push(new fabric.Text(`y = ${graphPanel.querySelector("#graphExpression").value}`,{left:12,top:8,fontSize:16,fill:color,fontWeight:"bold",backgroundColor:"rgba(255,255,255,.75)",selectable:false,evented:false}));
      const g=new fabric.Group(all,{left:260,top:170}); canvas.add(g); canvas.setActiveObject(g); saveCanvas(); graphPanel.classList.add("hidden");
    };

    // ---------- Calculator ----------
    let lastResult="";
    function calcEval(raw){
      let s=String(raw||"").trim()
        .replace(/,/g,".")
        .replace(/\^/g,"**")
        .replace(/π|\bpi\b/g,"Math.PI")
        .replace(/\bsqrt\(/g,"Math.sqrt(")
        .replace(/\bsin\(/g,"Math.sin(")
        .replace(/\bcos\(/g,"Math.cos(")
        .replace(/\btan\(/g,"Math.tan(")
        .replace(/(\d+(?:\.\d+)?)%/g,"($1/100)");
      const result=Function(`"use strict";return (${s})`)();
      if(!Number.isFinite(result))throw new Error();
      return Math.abs(result-Math.round(result))<1e-12?String(Math.round(result)):String(Number(result.toPrecision(12)));
    }

    calcPanel.querySelectorAll("[data-calc]").forEach(btn=>{
      btn.onclick=()=>{
        const display=calcPanel.querySelector("#calcDisplay");
        const v=btn.dataset.calc;
        if(v==="clear"){display.value="";calcPanel.querySelector("#calcResult").textContent="";return}
        if(v==="back"){display.value=display.value.slice(0,-1);return}
        if(v==="pi"){display.value+="π";return}
        if(v==="percent"){display.value+="%";return}
        display.value+=v; display.focus();
      };
    });

    function evaluate(){
      const display=calcPanel.querySelector("#calcDisplay");
      try{lastResult=calcEval(display.value);calcPanel.querySelector("#calcResult").textContent="= "+lastResult}
      catch(e){lastResult="";calcPanel.querySelector("#calcResult").textContent="Помилка у виразі"}
    }
    calcPanel.querySelector("#calcEquals").onclick=evaluate;
    calcPanel.querySelector("#calcDisplay").addEventListener("keydown",e=>{if(e.key==="Enter")evaluate()});
    calcPanel.querySelector("#calcInsert").onclick=()=>{
      if(!lastResult)evaluate();
      if(!lastResult)return;
      const text=`${calcPanel.querySelector("#calcDisplay").value} = ${lastResult}`;
      try{
        if(typeof insertTextIntoBoard==="function")insertTextIntoBoard(text);
        else{
          const canvas=getCanvas(); if(!canvas)return;
          const t=new fabric.IText(text,{left:300,top:200,fontSize:26,fill:"#17315f"});
          canvas.add(t); canvas.setActiveObject(t); saveCanvas();
        }
      }catch(e){}
      calcPanel.classList.add("hidden");
    };
  });
})();
